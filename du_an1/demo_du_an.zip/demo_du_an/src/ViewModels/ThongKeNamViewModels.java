/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModels;

/**
 *
 * @author TBC
 */
public class ThongKeNamViewModels {
     private int nam;
    private int tongHD;
    private int soLuongSPBan;
    private double doanhThu;

    public int getNam() {
        return nam;
    }

    public void setNam(int nam) {
        this.nam = nam;
    }

    public int getTongHD() {
        return tongHD;
    }

    public void setTongHD(int tongHD) {
        this.tongHD = tongHD;
    }

    public int getSoLuongSPBan() {
        return soLuongSPBan;
    }

    public void setSoLuongSPBan(int soLuongSPBan) {
        this.soLuongSPBan = soLuongSPBan;
    }

    public double getDoanhThu() {
        return doanhThu;
    }

    public void setDoanhThu(double doanhThu) {
        this.doanhThu = doanhThu;
    }
    
    
}
